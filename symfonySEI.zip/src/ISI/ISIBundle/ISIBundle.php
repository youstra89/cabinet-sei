<?php

namespace ISI\ISIBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class ISIBundle extends Bundle
{
}
