<?php
// src/Controller/LuckyController.php
namespace ISI\ISIBundle\Controller;

use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;

use ISI\ISIBundle\Entity\Rdv;
use ISI\ISIBundle\Entity\Message;
use ISI\ISIBundle\Repositiry\MessageRepositiry;

class ContactController extends Controller
{
    public function indexAction(Request $request)
    {
      $em = $this->getDoctrine()->getManager();
      if ($this->get('security.authorization_checker')->isGranted('IS_AUTHENTICATED_REMEMBERED')) {
        $user = $this->getUser();
        if(empty($user->getNom()) || empty($user->getPnom()))
        {
          $request->getSession()->getFlashBag()->add('warning', 'Veillez complèter votre profile avant de contituner.');
          return $this->redirectToRoute('update_profile');
        }
      }

      if($request->isMethod('post')){
        $nom     = $request->request->get('nom');
        $email   = $request->request->get('email');
        $subject = $request->request->get('subject');
        $content = $request->request->get('message');
        // return new Response(var_dump($nom));
        $message = new Message();
        if (!empty($this->getUser())) {
          $message->setUser($this->get('security.token_storage')->getToken()->getUser()->getId());
        }
        $message->setFullname($nom);
        $message->setEmail($email);
        $message->setSubject($subject);
        $message->setMessage($content);
        $message->setDateSave(new \Datetime());
        $message->setDateUpdate(new \Datetime());

        // return new Response(var_dump($message));
        $em->persist($message);
        $em->flush();
        $request->getSession()->getFlashBag()->add('success', 'Votre message a bien été délivré.');
        return $this->redirectToRoute('contact_us');
      }

      return $this->render('ISIBundle:Contact:index.html.twig', [
      ]);
    }

    public function rdvAction(Request $request)
    {
      if (!$this->get('security.authorization_checker')->isGranted('IS_AUTHENTICATED_REMEMBERED')) {
      // if (!$this->denyAccessUnlessGranted('IS_AUTHENTICATED_FULLY')) {
        $request->getSession()->getFlashBag()->add('warning', 'Veillez vous inscrire d\'abord avant de fixer un rendez-vous');
        return $this->redirectToRoute('fos_user_security_login');
      }

      $user = $this->getUser();
      if(empty($user->getNom()) || empty($user->getPnom()))
      {
        $request->getSession()->getFlashBag()->add('warning', 'Veillez complèter votre profile avant de contituner.');
        return $this->redirectToRoute('update_profile');
      }

      if($request->isMethod('post'))
      {
        $data = $request->request->all();
        $nom     = $data["nom"];
        $date    = $data["date"];
        $heure   = $data["heure"];
        $email   = $data["email"];
        $subject = $data["subject"];
        $message = $data["message"];

        if(empty($date))
        {
          $request->getSession()->getFlashBag()->add('error', 'Veillez choisir une date pour fixer votre rendez-vous!');
          return $this->redirectToRoute('rdv');
        }

        $good_format = strtotime ($date);
        if(date('N',$good_format) == 6 || date('N',$good_format) == 7)
        {
          $request->getSession()->getFlashBag()->add('error', 'Sélectionnez un jour ouvrable!');
          return $this->redirectToRoute('rdv');
        }
        if(empty($heure))
        {
          $request->getSession()->getFlashBag()->add('error', 'Veillez choisir une heure pour fixer votre rendez-vous!');
          return $this->redirectToRoute('rdv');
        }
        if(empty($subject))
        {
          $request->getSession()->getFlashBag()->add('error', 'Le sujet de votre message ne doit pas être vide');
          return $this->redirectToRoute('rdv');
        }
        if(empty($message))
        {
          $request->getSession()->getFlashBag()->add('error', 'Le message ne doit pas être vide');
          return $this->redirectToRoute('rdv');
        }
        $date = new \Datetime($date);
        // return new Response(var_dump($date));

        $rdv = new Rdv();
        $rdv->setUser($this->get('security.token_storage')->getToken()->getUser()->getId());
        $rdv->setDateRdv($date);
        $rdv->setHeure($heure);
        $rdv->setSubject($subject);
        $rdv->setMessage($message);
        $rdv->setDateSave(new \Datetime());
        $rdv->setDateUpdate(new \Datetime());

        $em = $this->getDoctrine()->getManager();
        $em->persist($rdv);
        $em->flush();

        $request->getSession()->getFlashBag()->add('success', 'Le rendez-vous à été bien enregistré.');
        return $this->redirectToRoute('contact_us');
      }

      return $this->render('ISIBundle:Contact:rdv.html.twig', [
      ]);
    }

    public function heuresNonDisponiblesAction(Request $request, $dateRdv)
    {
      $em = $this->getDoctrine()->getManager();
      // return new Response($date);
      // $dateRdv->format('Y-m-d');
      $requete_des_heures = "SELECT r.heure FROM rdv r WHERE r.date = :dateRdv;";
      $statement = $em->getConnection()->prepare($requete_des_heures);
      $statement->bindValue('dateRdv', $dateRdv);
      $statement->execute();
      $heures = $statement->fetchAll();


      $response = new JsonResponse($heures);
      return $response;

    }
}
