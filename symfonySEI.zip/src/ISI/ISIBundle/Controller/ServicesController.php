<?php
// src/Controller/LuckyController.php
namespace ISI\ISIBundle\Controller;

use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class ServicesController extends AbstractController
{
    public function indexAction()
    {
        return $this->render('ISIBundle:Services:index.html.twig', [
        ]);
    }


    public function constitutiondossiercampusfranceAction()
    {
        return $this->render('ISIBundle:Services:constitutiondossiercampusfrance.html.twig', [
        ]);
    }


    public function candidatureuniversitesAction()
    {
        return $this->render('ISIBundle:Services:candidatureuniversites.html.twig', [
        ]);
    }


    public function logementAction()
    {
        return $this->render('ISIBundle:Services:logement.html.twig', [
        ]);
    }


    public function constitutiondossiervisaAction()
    {
        return $this->render('ISIBundle:Services:constitutiondossiervisa.html.twig', [
        ]);
    }

}
