<?php
namespace ISI\ISIBundle\Controller;

use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\Security\Http\Util\TargetPathTrait;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Security;
use Symfony\Component\Security\Core\Authorization\AuthorizationCheckerInterface;
use Symfony\Component\Security\Core\Exception\AccessDeniedException;

use UserBundle\Entity\User;
use ISI\ISIBundle\Entity\Rdv;
use ISI\ISIBundle\Entity\Message;

class AdminController extends Controller
{
  /**
  * @Security("has_role('ROLE_ADMIN')")
  */
  public function indexAction(Request $request)
  {
    $em = $this->getDoctrine()->getManager();
    $repoRdv = $em->getRepository('ISIBundle:Rdv');
    $repoMessage = $em->getRepository('ISIBundle:Message');

    $userManager = $this->get('fos_user.user_manager');
    // $userManager = $container->get('fos_user.user_manager');
    $users = $userManager->findUsers();
    $rdv   = $repoRdv->findAll();
    $messages = $repoMessage->findByReadAt();
    // if (false === $authChecker->isGranted('ROLE_ADMIN')) {
    if (!$this->get('security.authorization_checker')->isGranted('ROLE_ADMIN')) {
        throw new AccessDeniedException('Vous n\'avez pas droit à cette ressources!');
    }
    return $this->render('ISIBundle:Admin:index.html.twig', [
      'msgNonLus' => count($messages),
      'nbrUsers'  => count($users),
      'nbrRdv'    => count($rdv)
    ]);
  }

  /**
  * @Security("has_role('ROLE_ADMIN')")
  */
  public function messagesAction(Request $request)
  {
    $em = $this->getDoctrine();
    $repoMessage = $em->getRepository(Message::class);
    $messages = $repoMessage->findAll();
    if (!$this->get('security.authorization_checker')->isGranted('ROLE_ADMIN')) {
        throw new AccessDeniedException('Vous n\'avez pas droit à cette ressources!');
    }
    return $this->render('ISIBundle:Admin:messages.html.twig', [
      'messages' => $messages
    ]);
  }

  /**
  * @Security("has_role('ROLE_ADMIN')")
  */
  public function membresAction(Request $request)
  {
    $em = $this->getDoctrine();
    $repoUser = $em->getRepository(User::class);
    $users    = $repoUser->findAll();
    if (!$this->get('security.authorization_checker')->isGranted('ROLE_ADMIN')) {
        throw new AccessDeniedException('Vous n\'avez pas droit à cette ressources!');
    }
    return $this->render('ISIBundle:Admin:membres.html.twig', [
      'users'  => $users
    ]);
  }

  /**
  * @Security("has_role('ROLE_ADMIN')")
  */
  public function lireMessageAction(Request $request, $id)
  {
    $em = $this->getDoctrine()->getManager();
    $repoMessage = $em->getRepository(Message::class);
    $message = $repoMessage->find($id);
    if (!$this->get('security.authorization_checker')->isGranted('ROLE_ADMIN')) {
        throw new AccessDeniedException('Vous n\'avez pas droit à cette ressources!');
    }
    $message->setReadAt(new \Datetime());
    $em->flush();
    return $this->render('ISIBundle:Admin:lire-message.html.twig', [
      'message' => $message
    ]);
  }

  /**
  * @Security("has_role('ROLE_ADMIN')")
  */
  public function tousLesRdvAction(Request $request)
  {
    $em = $this->getDoctrine()->getManager();
    $repoRdv = $em->getRepository("ISIBundle:Rdv");
    $rdv = $repoRdv->findAll();
    if (!$this->get('security.authorization_checker')->isGranted('ROLE_ADMIN')) {
        throw new AccessDeniedException('Vous n\'avez pas droit à cette ressources!');
    }

    foreach ($rdv as $key => $r) {
      $date[$key]  = $r->getDateRdv();
      $heure[$key] = $r->getHeure();
    }
    array_multisort($date, SORT_ASC, $heure, SORT_ASC, $rdv);

    return $this->render('ISIBundle:Admin:rdv.html.twig', [
      'rdv' => $rdv
    ]);
  }

  /**
  * @Security("has_role('ROLE_ADMIN')")
  */
  public function voirRdvAction(Request $request, $id)
  {
    $em = $this->getDoctrine()->getManager();
    $repoRdv = $em->getRepository("ISIBundle:Rdv");
    $rdv = $repoRdv->find($id);
    if (!$this->get('security.authorization_checker')->isGranted('ROLE_ADMIN')) {
        throw new AccessDeniedException('Vous n\'avez pas droit à cette ressources!');
    }

    if($request->isMethod('post'))
    {
      $data = $request->request->all();
      $heureArrivee = $data['heureArrivee'];
      $commentaire  = $data['commentaire'];
      if(empty($heureArrivee) || empty($commentaire))
      {
        $request->getSession()->getFlashBag()->add('error', 'Le formualire n\'est pas complet. Il manque l\'heure ou le commentaire.');
        return $this->redirectToRoute('voir_rdv', ['id' => $id]);
      }

      $rdv->setHeureArrivee($heureArrivee);
      $rdv->setCommentaire($commentaire);
      $em->flush();
      $request->getSession()->getFlashBag()->add('success', 'Les informations sur le rendez-vous ont été enregistrées avec succès.');
      return $this->redirectToRoute('tous_les_rdv');
    }

    return $this->render('ISIBundle:Admin:voir-rdv.html.twig', [
      'rdv' => $rdv
    ]);
  }
}
