<?php
// src/Controller/LuckyController.php
namespace ISI\ISIBundle\Controller;

use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class CountriesController extends AbstractController
{
    public function indexAction()
    {
        return $this->render('ISIBundle:Countries:index.html.twig', [
        ]);
    }


    public function franceAction()
    {
        return $this->render('ISIBundle:Countries:france.html.twig', [
        ]);
    }

    public function belgiqueAction()
    {
        return $this->render('ISIBundle:Countries:belgique.html.twig', [
        ]);
    }

    public function canadaAction()
    {
        return $this->render('ISIBundle:Countries:canada.html.twig', [
        ]);
    }

    public function marocAction()
    {
        return $this->render('ISIBundle:Countries:maroc.html.twig', [
        ]);
    }



    // public function rdv()
    // {
    //
    // }
}
