<?php

namespace ServicesBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class ServicesBundle extends Bundle
{
}
